This file should viewed in UTF8 format.

老师，在Linux里没有VC6，就直接拿 Makefile 弄了
当然拿QT也可, 直接开 DSAA.pro 即可
