#include "Applications.h"
#include <cstddef>
#include <cstdarg>

//多项式计算1，返回结果
//a[]: 存放多项式的各项系数a[0]最高位，如4x4+6x3-2.3x2+0x+2x0    对应4 6 -2.3  0  2    n值为5
//len：数组长度   n:有效元素个数
//x：变量
//return:返回多项式计算结果
double  PolynomialFunc(double * a, int len, int n, double x)
{
  double sum = 0;
  if(a==NULL || n<=0) return 0.0;
  n = n<=len ? n : len;

  for(int i=0;i<n;++i){
    sum = sum*x + a[i];
  }

  return sum;
}

//多项式计算2，返回结果
//n: 多项式个数， 如n=4  最高位就是x的三次方
//x：最高位系数，后面可变参数，一次为多项式的各阶系数
//return:返回多项式计算结果
double  PolynomialFunc(int n, double x, ...)
{
  double sum = 0;
  va_list args;
  va_start(args,n);
  for(int i=0;i<n;++i){
    sum = sum*x + va_arg(args,double);
  }
  va_end(args);
  
  return sum;
}
