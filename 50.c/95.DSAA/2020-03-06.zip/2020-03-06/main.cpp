#include <cstdio>
#include <cstdlib>
#include <cmath>

#include "Applications.h"
#include "Array.h"
#include "SingleLinkedList.h"
#include "DoubleLinkedList.h"

void testApp(){
  // f[x] = 1x^4 + 5x^2 + -8x - 12
  double a[] = {1,0,5,-8,-12};
  for(int x = -4;x<=4;++x){
    double f1 = PolynomialFunc(a,5,5,x);
    double f2 = PolynomialFunc(5,x,a[0],a[1],a[2],a[3],a[4]);
    if(fabs(f1 - f2)>1e-6){
      throw "  wrong at Application.cpp\n";
      exit(1);
    }
    printf("f[%d]: %lf\n",x,f1);
  }
}

void testArray(){
  int *a = new int [1020];
  auto print = [](int *a, int n, const char *s=nullptr){
    if(s) printf("%s ",s);
    printf("a[%d]:",n);
    for(int i=0;i<n;++i)
      printf(" %d",a[i]);
    putchar('\n');
  };

  a[0] = 1,
  a[1] = 2,
  a[2] = 2,
  a[3] = 2,
  a[4] = 4,
  a[5] = 8;

  int n = 6;
  print(a,n,"before delete");
  n = cyf_DeleteElement(a,1020,n,0);
  print(a,n,"delete 0");

  n = cyf_DeleteElement(a,1020,n,2);
  print(a,n,"delete 2");

  n = cyf_DeleteElement(a,1020,n,1);
  print(a,n,"delete 1");

  n = cyf_DeleteElement(a,1020,n,4);
  print(a,n,"delete 4");

  n = cyf_DeleteElement(a,1020,n,8);
  print(a,n,"delete 8");


  a[0] = 1,
  a[1] = 2,
  a[2] = 2,
  a[3] = 2,
  a[4] = 4,
  a[5] = 8;

  n = 6;
  print(a,n,"before add one");
  n = cyf_AddElement(a,1020,n,0);
  print(a,n,"add 0");

  n = cyf_AddElement(a,1020,n,1024);
  print(a,n,"add 1024");

  n = cyf_AddElement(a,1020,n,4);
  print(a,n,"add 4");

  int *b = new int [8];
  b[0] = -256,
  b[1] = 0,
  b[2] = 1,
  b[3] = 1,
  b[4] = 5,
  b[5] = 2048;

  int lena=1020;
  cyf_AddElement(a,lena,n,b,8,6);
  print(b,6);
  print(a,n,"add b");
}

template<typename T> void testList(){
  auto print = [](T *head, const char *s=nullptr){
    if(s) printf("%s ",s);
    ShowAllPigs(head);
  };
  T v[] = { {"a", 5}, {"b", 4}, {"c", 10}, {"d", 12}, {"e", 2} };
  auto head = CreatePigs(5,v);
  print(head);

  head = InsertPig(head, {"pigga", 2});
  head = InsertPig(head, {"###", 1024});
  print(head, "insert 2 pig");

  head = SortPigsByName(head);
  print(head, "sort by name");

  head = SortPigsByWeight(head);
  print(head, "sort by weight");


  head = KillPigByWeight(head, 1024);
  print(head, "kill weight 1024");

  head = KillPigByName(head, "pigga");
  print(head, "kill name pigga");
}

int main(void)
{
  testApp();
  testArray();
  testList<PigNode>();
  testList<DPigNode>();

  return 0;
} 
