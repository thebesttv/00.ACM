This file should be viewed in UTF8 format.

操作系统: Linux
编译器: GNU GCC 9.2.1
编译命令:
  g++ -c Applications.cpp -o Applications.o
  g++ -c Array.cpp -o Array.o
  g++ -c SingleLinkedList.cpp -o SingleLinkedList.o
  g++ -c DoubleLinkedList.cpp -o DoubleLinkedList.o
  g++ main.cpp -o DSAA.out Array.o Applications.o SingleLinkedList.o DoubleLinkedList.o

所有文件都为 UTF8 编码
使用了 lambda 表达式
