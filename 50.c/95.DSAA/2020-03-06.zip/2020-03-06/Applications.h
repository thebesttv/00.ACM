#ifndef __APPLICATIONS_H__
#define __APPLICATIONS_H__

//多项式计算1，返回结果
//a[]: 存放多项式的各项系数a[0]最高位，如4x4+6x3-2.3x2+0x+2x0    对应4 6 -2.3  0  2    n值为5
//len：数组长度   n:有效元素个数
//x：变量
//return:返回多项式计算结果
double  PolynomialFunc(double * a, int len, int n, double x);

//多项式计算2，返回结果
//n: 多项式个数， 如n=4  最高位就是x的三次方
//x：最高位系数，后面可变参数，一次为多项式的各阶系数
//return:返回多项式计算结果
double  PolynomialFunc(int n, double x, ...);

#endif