#include "Applications.h"
#include <stdarg.h>
#include <cstdio>
#include <vector>
#include <stack>
#include "ArrayStack.h"
#include "ListLinkedStack.h"

//����ʽ����1�����ؽ��
//a[]: ��Ŷ���ʽ�ĸ���ϵ��a[0]���λ����4x4+6x3-2.3x2+0x+2x0    ��Ӧ4 6 -2.3  0  2    nֵΪ5
//len�����鳤��   n:��ЧԪ�ظ���
//x������
//return:���ض���ʽ������
double  PolynomialFunc(double * a, int len, int n, double x)
{
	double sum = 0;
    for(int i = 0; i < n; ++i)
        sum = sum*x + a[i];
	return sum;
}

//����ʽ����2�����ؽ��
//n: ����ʽ������ ��n=4  ���λ����x�����η�
//x�����λϵ��������ɱ������һ��Ϊ����ʽ�ĸ���ϵ��
//return:���ض���ʽ������
double  PolynomialFunc(int n, ...) {
	double sum = 0;
    va_list args;
    va_start(args, n);
    double x = va_arg(args, double);
    for(int i = 0; i < n; ++i){
        sum = sum*x + va_arg(args, double);
    }
    va_end(args);
	
	return sum;
}


struct Token{
    int type;   // 0: number, 1: operator
    double v;
    Token(int _type, double _v){
        type = _type, v = _v;
    }
};

void eval(std::stack<double> &nst, std::stack<char> &ost){
    double x1,x2,x;
    x2=nst.top(); nst.pop();
    x1=nst.top(); nst.pop();
    char op = ost.top(); ost.pop();
    switch(op){
        case '+': x = x1+x2; break;
        case '-': x = x1-x2; break;
        case '*': x = x1*x2; break;
        case '/': x = x1/x2; break;
    }
    nst.push(x);
}

double FourMixedOperations(const char *str) {
    std::vector<Token> token;
    int i = 0;
    while(str[i]){
        if(isdigit(str[i]) || str[i]=='.'){
            double v=0;
            while(isdigit(str[i])){
                v = v*10 + str[i]-'0';
                ++i;
            }
            if(str[i]=='.'){
                ++i; double t = 10;
                while(isdigit(str[i])){
                    v += (str[i]-'0')/t;
                    t*=10, ++i;
                }
            }
            token.push_back(Token(0,v));
        }else if(str[i]!=' '){
            token.push_back(Token(1,str[i]));
            ++i;
        }else{
            ++i;
        }
    }

    std::stack<double> nst;
    std::stack<char> ost;

    for(i=0;i<token.size();++i){
        Token p = token[i];
#ifdef DEBUG
        if(p.type==0) printf("  %lf\n",p.v);
        else printf("  %c\n",char(int(p.v)));
#endif
        if(p.type==0){
            nst.push(p.v);
        }else{
            char op=char(int(p.v));
            if(op=='(' || op=='*' || op=='/'){
                ost.push(op);
            }else if(op==')'){
                while(ost.top()!='(') eval(nst,ost);
                ost.pop();
            }else{  // +, -
                while(!ost.empty() && (ost.top()=='*' || ost.top()=='/'))
                    eval(nst,ost);
                ost.push(op);
            }
        }
    }
    while(!ost.empty()) eval(nst,ost);
    return nst.top();
}

const char _decToHex[]={'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};

void _DecToHexByRec(int n, char *& p){
    if(!n) return;
    _DecToHexByRec(n/16, p);
    *p++ = _decToHex[n%16];
}

//��ҵ2����ɽ���ת�� ʹ��ջ�Ľṹ��
//����int  17
//��� "0x11"
char * DecToHexByRecursion(int n)  //�ݹ�ķ�ʽ
{
    char * s = new char[100], *p = s;
    if(!n){
        *p++='0', *p++=0;
        return s;
    }
    if(n<0) *p++='-', n=-n;
    _DecToHexByRec(n, p);
    *p++ = 0;

    return s;
}


char * DecToHexByStack1(int n)     //��ͨ����16 ѹջ�ķ�ʽ ��������ջ
{
    char * s = new char[100], *p = s;
    if(!n){
        *p++='0', *p++=0;
        return s;
    }
    if(n<0) *p++='-', n=-n;

    ArrayStack<char> st;
    while(n){
        st.push(_decToHex[n%16]);
        n/=16;
    }
    while(!st.empty()){
        *p++ = st.top();
        st.pop();
    }
    *p++ = 0;

    return s;
}

char * DecToHexByStack2(int n)     //��λ���� ѹջ ��ջ
{
    char * s = new char[100], *p = s;
    if(!n){
        *p++='0', *p++=0;
        return s;
    }
    if(n<0) *p++='-', n=-n;

    ListStack<char> st;
    while(n){
        st.push(_decToHex[n%16]);
        n>>=4;
    }
    while(!st.empty()){
        *p++ = st.top();
        st.pop();
    }
    *p++ = 0;

    return s;
}
