#include "ArrayQueue.h"
#include "ArrayStack.h"
#include "LIstLinkedQueue.h"
#include "ListLinkedStack.h"
#include "Applications.h"
#include <stdio.h>
#include <stdlib.h>

void testStack1();
void testQueue1();
void testStack2();
void testQueue2();
void testDec2Hex();
void testExpression();

int main(void){
    testQueue1();
    testQueue2();
    testStack1();
    testStack2();
    testDec2Hex();
    testExpression();
    return 0;
}

void testExpression(){
    const int n = 5;
    const char *s[n] = {
        "0",
        "1+2+3+4",
        "1*2-3/4",
        "(1+2)*3/4+1",
        "((((2+2)))-3)*4"
    };
    for(int i=0;i<n;++i){
        printf("Expression: %s\n",s[i]);
        printf("  ans: %lf\n",FourMixedOperations(s[i]));
    }
}

void testDec2Hex(){
    for(int n=-1000;n<=1000;n+=100){
        char *s1 = DecToHexByStack1(n),
             *s2 = DecToHexByStack2(n),
             *s3 = DecToHexByRecursion(n);
        if(strcmp(s1,s2) || strcmp(s2,s3)){
            throw "error in Dec2Hex";
            exit(1);
        }
        printf("Dec2Hec(%d): %s\n",n,s1);
        delete [] s1;
        delete [] s2;
        delete [] s3;
    }
}

void testQueue2(){
    ListQueue<int> q;
    q.push(1),
    q.push(2),
    q.push(3),
    q.push(4),
    q.push(5);

    q.print();
    std::cout << "front: " << q.front() << std::endl;
    std::cout << "back: " << q.back() << std::endl;
    while(!q.empty()){
        std::cout << "front & pop: " << q.front() << std::endl;
        q.pop();
        q.print();
    }

    q.push(6),
    q.push(7),
    q.push(8),
    q.push(9),
    q.push(10);
    q.print("refill");
}

void testStack2(){
    ListStack<int> st;
    st.push(1);
    st.push(2);
    st.push(3);
    st.push(4);
    st.push(5);

    st.print();
    while(!st.empty()){
        std::cout << "top & pop: " << st.top() << std::endl;
        st.pop();
        st.print();
    }
}

void testQueue1(){
    ArrayQueue<int> q;
    q.push(1),
    q.push(2),
    q.push(3),
    q.push(4),
    q.push(5);

    q.print();
    std::cout << "front: " << q.front() << std::endl;
    std::cout << "back: " << q.back() << std::endl;
    while(!q.empty()){
        std::cout << "front & pop: " << q.front() << std::endl;
        q.pop();
        q.print();
    }

    q.push(6),
    q.push(7),
    q.push(8),
    q.push(9),
    q.push(10);
    q.print("refill");
}

void testStack1(){
    ArrayStack<int> st;
    st.push(1);
    st.push(2);
    st.push(3);
    st.push(4);
    st.push(5);

    st.print();
    while(!st.empty()){
        std::cout << "top & pop: " << st.top() << std::endl;
        st.pop();
        st.print();
    }
}

/*
#include "Applications.h"
//#include "Array.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

//#define TEST_SINGLE
//#ifdef TEST_SINGLE
//#include "SingleLinkedList.h"
//#else
//#include "DoubleLinkedList.h"
//#endif

template<typename T>
void testList();
void testPoly();
void printArray(int *a, int n, const char *s=0);
void testArray();

int main(void) {
    testPoly();
    testArray();
#ifdef TEST_SINGLE
    testList<PigNode>();
#else
    testList<DPigNode>();
#endif
    //printf("%s\n", DecToHexByRecursion(1024));
    getchar();
    return 0;
}

template<typename T>
void testList(){
    T v[] = { T("a", 5), T("b", 4), T("c", 10), T("d", 12), T("e", 2) };
    T *head = CreatePigs(5,v);
    ShowAllPigs(head);

    head = InsertPig(head, T("pigga", 2));
    head = InsertPig(head, T("###", 1024));
    ShowAllPigs(head, "insert 2 pig");

    head = SortPigsByName(head);
    ShowAllPigs(head, "sort by name");

    head = SortPigsByWeight(head);
    ShowAllPigs(head, "sort by weight");

    head = KillPigByWeight(head, 1024);
    ShowAllPigs(head, "kill weight 1024");

    head = KillPigByName(head, "pigga");
    ShowAllPigs(head, "kill name pigga");
}

void testPoly(){
    // f[x] = 1x^4 + 5x^2 + -8x - 12
    double a[5] = {1,0,5,-8,-12};
    for(int x = -4; x <= 4; ++x){
        double f1 = PolynomialFunc(a,5,5,x);
        double f2 = PolynomialFunc(6, x, a[0], a[1], a[2], a[3], a[4]);
        if(fabs(f1 - f2)>1e-6){
            printf("  wrong at Application.cpp\n");
            exit(1);
        }
        printf("f[%d]: %lf\n",x,f1);
    }
}

void printArray(int *a, int n, const char *s=0){
    if(s) printf("%s ",s);
    printf("a[%d]:",n);
    for(int i=0;i<n;++i)
        printf(" %d",a[i]);
    putchar('\n');
}

void testArray(){
    int *a = new int [1020];


    a[0] = 1,
    a[1] = 2,
    a[2] = 2,
    a[3] = 2,
    a[4] = 4,
    a[5] = 8;

    int n = 6;
    printArray(a,n,"before delete");
    n = cyf_DeleteElement(a,1020,n,0);
    printArray(a,n,"delete 0");

    n = cyf_DeleteElement(a,1020,n,2);
    printArray(a,n,"delete 2");

    n = cyf_DeleteElement(a,1020,n,1);
    printArray(a,n,"delete 1");

    n = cyf_DeleteElement(a,1020,n,4);
    printArray(a,n,"delete 4");

    n = cyf_DeleteElement(a,1020,n,8);
    printArray(a,n,"delete 8");


    a[0] = 1,
    a[1] = 2,
    a[2] = 2,
    a[3] = 2,
    a[4] = 4,
    a[5] = 8;

    n = 6;
    printArray(a,n,"before add one");
    n = cyf_AddElement(a,1020,n,0);
    printArray(a,n,"add 0");

    n = cyf_AddElement(a,1020,n,1024);
    printArray(a,n,"add 1024");

    n = cyf_AddElement(a,1020,n,4);
    printArray(a,n,"add 4");

    int *b = new int [8];
    b[0] = -256,
    b[1] = 0,
    b[2] = 1,
    b[3] = 1,
    b[4] = 5,
    b[5] = 2048;

    int lena=1020;
    cyf_AddElement(a,lena,n,b,8,6);
    printArray(b,6);
    printArray(a,n,"add b");
}
*/