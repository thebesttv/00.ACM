#ifndef BASE_H
#define BASE_H

#define DEBUG
const int STACK_SIZE = 2;
const int VECTOR_SIZE = 2;
const int QUEUE_SIZE = 2;

#include <iostream>
#include <cstdio>

#endif // BASE_H